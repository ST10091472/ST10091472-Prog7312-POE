Citizen Care Reporting Application


Application Requirements
Framework: .NET Framework 4.8 (or higher)
IDE: Visual Studio 2019 (or newer)
Target Platform: Windows OS
How to Compile the Program
To compile and run the program, follow these steps:

Install Visual Studio:

Download and install Visual Studio.
Ensure that the ".NET desktop development" workload is selected during the installation process.
Clone or Download the Project:

Clone the repository using Git or download the project zip from the source location.
If downloaded as a zip, extract the contents to a known directory.
Open the Project in Visual Studio:

Open Visual Studio and click on File > Open > Project/Solution.
Browse to the project directory and select the .sln file.
Build the Solution:

In the Solution Explorer, right-click on the project and select Build.
Ensure there are no build errors.
Running the Application:

Once the project is built, press F5 or click Start in Visual Studio to run the application in Debug Mode.
Alternatively, you can build the project in Release Mode for a production build (explained below).
How to Run the Application (Non-Developer Instructions)
To run the application as a user without developer tools, follow these steps:

Download and Install Dependencies:

Ensure that the system has the .NET Framework 4.8 (or higher) installed. If not, download and install it from the Microsoft website.
Navigate to Release Folder:

After building the application in Release Mode:
In Visual Studio, go to Build > Configuration Manager.
Set the configuration to Release and build the project.
Navigate to the bin/Release folder inside the project directory.
Run the Executable:

Locate the Program.exe file within the bin/Release folder.
Double-click the Program.exe file to start the application.
