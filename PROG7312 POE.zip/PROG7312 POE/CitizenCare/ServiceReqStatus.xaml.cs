﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CitizenCare
{
    /// <summary>
    /// Interaction logic for ServiceReqStatus.xaml
    /// </summary>
    public partial class ServiceReqStatus : Window
    {
        private AVLTree avlTree = new(); // Assuming AVL Tree is implemented
        private DependencyGraph dependencyGraph = new(); // Assuming DependencyGraph is implemented
        private MinHeap priorityQueue = new(); // Assuming MinHeap is implemented
        private List<ServiceRequest> displayedRequests = new();

        public ServiceReqStatus()
        {
            InitializeComponent();
            LoadData(); // Load sample data
            RefreshGrid();
        }

        private void RefreshGrid()
        {
            displayedRequests = avlTree.InOrderTraversal(); // Fetch sorted requests from AVL Tree
            ServiceRequestsGrid.ItemsSource = null;         // Clear old data
            ServiceRequestsGrid.ItemsSource = displayedRequests; // Bind the data
        }

        private void AddRequest_Click(object sender, RoutedEventArgs e)
        {
            // Simulate adding a request (in a real app, get inputs from a form)
            var newRequest = new ServiceRequest
            {
                RequestId = 100 + displayedRequests.Count + 1,
                Description = "New Request",
                Status = "Pending",
                Priority = (displayedRequests.Count % 3) + 1
            };

            avlTree.Insert(newRequest);             // Add to AVL Tree
            priorityQueue.Insert(newRequest);       // Add to Min-Heap
            dependencyGraph.AddEdge(newRequest.RequestId, newRequest.RequestId + 1); // Simulate dependency
            RefreshGrid();
        }

        private void SearchRequest_Click(object sender, RoutedEventArgs e)
        {
            int searchId = 101; // Replace with user input in a real app
            var result = avlTree.Search(searchId);

            if (result != null)
            {
                MessageBox.Show($"Request Found:\nID: {result.RequestId}\nDescription: {result.Description}\nStatus: {result.Status}\nPriority: {result.Priority}");
            }
            else
            {
                MessageBox.Show($"Request ID {searchId} not found.");
            }
        }

        private void ShowDependencies_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int requestId = int.Parse(RequestIdTextBox.Text); // Get RequestId from TextBox input
                var dependencies = dependencyGraph.GetDependencies(requestId);

                if (dependencies.Count > 0)
                {
                    MessageBox.Show($"Dependencies for Request ID {requestId}: {string.Join(", ", dependencies)}");
                }
                else
                {
                    MessageBox.Show($"No dependencies found for Request ID {requestId}.");
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter a valid Request ID.");
            }
        }

        private void LoadData()
        {
            // Sample service requests
            var requests = new List<ServiceRequest>
            {
                new ServiceRequest { RequestId = 101, Description = "Fix network issue", Status = "Pending", Priority = 2 },
                new ServiceRequest { RequestId = 102, Description = "Install software", Status = "Completed", Priority = 1 },
                new ServiceRequest { RequestId = 103, Description = "Replace hardware", Status = "In Progress", Priority = 3 },
            };

            foreach (var request in requests)
            {
                avlTree.Insert(request); // Use avlTree instead of BST
                priorityQueue.Insert(request); // Add to MinHeap
                dependencyGraph.AddEdge(request.RequestId, request.RequestId + 1); // Simulate dependency
            }
        }
    }

}