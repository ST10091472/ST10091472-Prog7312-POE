﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CitizenCare
{
    public class AVLTree
    {
        public class Node
        {
            public ServiceRequest Data { get; set; }
            public Node Left { get; set; }
            public Node Right { get; set; }
            public int Height { get; set; }
        }

        public Node Root { get; private set; }

        public ServiceRequest Search(int id)
        {
            return SearchRec(Root, id);
        }

        private ServiceRequest SearchRec(Node node, int id)
        {
            if (node == null)
                return null;

            if (node.Data.RequestId == id)
                return node.Data;

            if (id < node.Data.RequestId)
                return SearchRec(node.Left, id);

            return SearchRec(node.Right, id);
        }

        public void Insert(ServiceRequest request)
        {
            Root = InsertRec(Root, request);
        }

        private Node InsertRec(Node node, ServiceRequest request)
        {
            if (node == null)
                return new Node { Data = request, Height = 1 };

            if (request.RequestId < node.Data.RequestId)
                node.Left = InsertRec(node.Left, request);
            else if (request.RequestId > node.Data.RequestId)
                node.Right = InsertRec(node.Right, request);
            else
                return node; // Duplicate keys not allowed.

            node.Height = 1 + Math.Max(GetHeight(node.Left), GetHeight(node.Right));

            // Balance the node
            int balance = GetBalance(node);

            // Left Left Case
            if (balance > 1 && request.RequestId < node.Left.Data.RequestId)
                return RightRotate(node);

            // Right Right Case
            if (balance < -1 && request.RequestId > node.Right.Data.RequestId)
                return LeftRotate(node);

            // Left Right Case
            if (balance > 1 && request.RequestId > node.Left.Data.RequestId)
            {
                node.Left = LeftRotate(node.Left);
                return RightRotate(node);
            }

            // Right Left Case
            if (balance < -1 && request.RequestId < node.Right.Data.RequestId)
            {
                node.Right = RightRotate(node.Right);
                return LeftRotate(node);
            }

            return node;
        }

        private int GetHeight(Node node) => node?.Height ?? 0;

        private int GetBalance(Node node) => node == null ? 0 : GetHeight(node.Left) - GetHeight(node.Right);

        private Node RightRotate(Node y)
        {
            Node x = y.Left;
            Node T2 = x.Right;

            // Perform rotation
            x.Right = y;
            y.Left = T2;

            // Update heights
            y.Height = Math.Max(GetHeight(y.Left), GetHeight(y.Right)) + 1;
            x.Height = Math.Max(GetHeight(x.Left), GetHeight(x.Right)) + 1;

            return x;
        }

        private Node LeftRotate(Node x)
        {
            Node y = x.Right;
            Node T2 = y.Left;

            // Perform rotation
            y.Left = x;
            x.Right = T2;

            // Update heights
            x.Height = Math.Max(GetHeight(x.Left), GetHeight(x.Right)) + 1;
            y.Height = Math.Max(GetHeight(y.Left), GetHeight(y.Right)) + 1;

            return y;
        }

        public List<ServiceRequest> InOrderTraversal()
        {
            var result = new List<ServiceRequest>();
            InOrderTraversalRec(Root, result);
            return result;
        }

        private void InOrderTraversalRec(Node node, List<ServiceRequest> result)
        {
            if (node != null)
            {
                InOrderTraversalRec(node.Left, result);
                result.Add(node.Data);
                InOrderTraversalRec(node.Right, result);
            }
        }
    }
}
