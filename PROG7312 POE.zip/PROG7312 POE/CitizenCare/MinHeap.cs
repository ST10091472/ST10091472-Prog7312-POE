﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CitizenCare
{
    public class MinHeap
    {
        private List<ServiceRequest> heap = new();

        public void Insert(ServiceRequest request)
        {
            heap.Add(request);
            int currentIndex = heap.Count - 1;

            while (currentIndex > 0)
            {
                int parentIndex = (currentIndex - 1) / 2;

                if (heap[currentIndex].Priority >= heap[parentIndex].Priority)
                    break;

                Swap(currentIndex, parentIndex);
                currentIndex = parentIndex;
            }
        }

        public ServiceRequest ExtractMin()
        {
            if (heap.Count == 0) return null;

            var min = heap[0];
            heap[0] = heap[heap.Count - 1];
            heap.RemoveAt(heap.Count - 1);

            MinHeapify(0);

            return min;
        }

        private void MinHeapify(int index)
        {
            int smallest = index;
            int left = 2 * index + 1;
            int right = 2 * index + 2;

            if (left < heap.Count && heap[left].Priority < heap[smallest].Priority)
                smallest = left;

            if (right < heap.Count && heap[right].Priority < heap[smallest].Priority)
                smallest = right;

            if (smallest != index)
            {
                Swap(index, smallest);
                MinHeapify(smallest);
            }
        }

        private void Swap(int i, int j)
        {
            var temp = heap[i];
            heap[i] = heap[j];
            heap[j] = temp;
        }

        public bool IsEmpty() => heap.Count == 0;
    }

}
