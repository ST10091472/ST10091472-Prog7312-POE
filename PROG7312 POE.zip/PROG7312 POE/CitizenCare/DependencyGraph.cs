﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CitizenCare
{
    class DependencyGraph
    {
        private readonly Dictionary<int, List<int>> adjList = new();

        // Adds an edge from 'from' to 'to' (a dependency from 'from' to 'to')
        public void AddEdge(int from, int to)
        {
            if (!adjList.ContainsKey(from))
                adjList[from] = new List<int>();
            adjList[from].Add(to);
        }

        // Performs a Depth-First Search (DFS) starting from the given node
        public List<int> DFS(int startNode)
        {
            var visited = new HashSet<int>();
            var result = new List<int>();
            DFSUtil(startNode, visited, result);
            return result;
        }

        // Utility method for DFS traversal
        private void DFSUtil(int node, HashSet<int> visited, List<int> result)
        {
            if (!visited.Contains(node))
            {
                visited.Add(node);
                result.Add(node);

                // Traverse all the neighbors of the current node
                if (adjList.ContainsKey(node))
                {
                    foreach (var neighbor in adjList[node])
                        DFSUtil(neighbor, visited, result);
                }
            }
        }

        // Retrieves the dependencies for a given requestId
        public List<int> GetDependencies(int requestId)
        {
            // Return the dependencies if they exist for the given requestId, otherwise return an empty list
            if (adjList.ContainsKey(requestId))
            {
                return adjList[requestId];
            }
            return new List<int>(); // Return an empty list if no dependencies exist for this requestId
        }

        // Performs a Breadth-First Search (BFS) starting from the given node
        public List<int> BFS(int startNode)
        {
            var visited = new HashSet<int>();
            var queue = new Queue<int>();
            var result = new List<int>();

            queue.Enqueue(startNode);
            visited.Add(startNode);

            // Perform BFS traversal
            while (queue.Count > 0)
            {
                var node = queue.Dequeue();
                result.Add(node);

                // Traverse all unvisited neighbors of the current node
                if (adjList.ContainsKey(node))
                {
                    foreach (var neighbor in adjList[node])
                    {
                        if (!visited.Contains(neighbor))
                        {
                            visited.Add(neighbor);
                            queue.Enqueue(neighbor);
                        }
                    }
                }
            }

            return result;
        }
    }
}