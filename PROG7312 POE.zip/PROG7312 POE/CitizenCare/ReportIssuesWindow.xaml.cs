﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CitizenCare
{
    /// <summary>
    /// Interaction logic for ReportIssuesWindow.xaml
    /// </summary>
    public partial class ReportIssuesWindow : Window
    {
        public ReportIssuesWindow()
        {
            InitializeComponent();
        }

        // Handle Media Attachment
        private void btnAttachMedia_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image files (*.png;*.jpg)|*.png;*.jpg|All files (*.*)|*.*";
            if (openFileDialog.ShowDialog() == true)
            {
                // Logic to attach the media file (e.g., store file path)
                lblEngagement.Content = "Media attached: " + openFileDialog.FileName;
            }
        }

        // Handle Submit Button
        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            string location = txtLocation.Text;
            string category = (comboCategory.SelectedItem as ComboBoxItem)?.Content.ToString();
            string description = new TextRange(richDescription.Document.ContentStart, richDescription.Document.ContentEnd).Text;

            // Validate inputs
            if (string.IsNullOrWhiteSpace(location) || string.IsNullOrWhiteSpace(category) || string.IsNullOrWhiteSpace(description))
            {
                lblEngagement.Content = "Please complete all fields.";
                return;
            }

            // Save issue (logic for saving can be extended with file or database storage)
            Issue newIssue = new Issue(location, category, description);
            lblEngagement.Content = "Issue reported successfully!";
        }

        // Handle Back Button
        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close(); // Close the current window
        }
    }
}

