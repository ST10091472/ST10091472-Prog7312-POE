﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CitizenCare
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnReportIssues_Click(object sender, RoutedEventArgs e)
        {
            ReportIssuesWindow reportWindow = new ReportIssuesWindow();
            reportWindow.Show();
            this.Close(); // Close the main window when opening the report issues window
        }

        private void btnLocalEvents_Click(object sender, RoutedEventArgs e)
        {
            LocalEventsWindow LocalEventsWindow = new LocalEventsWindow();
            LocalEventsWindow.Show();
            this.Close(); // Close the main window when opening the report issues window
        }

        private void btnServiceReqStatus_Click(object sender, RoutedEventArgs e)
        {
            ServiceReqStatus ServiceReqStatus = new ServiceReqStatus();
            ServiceReqStatus.Show();
            this.Close(); // Close the main window when opening the report issues window
        }
    }
}