﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CitizenCare
{
    internal class BST<T> where T : IComparable<T>
    {
        private Node<T> root;

        public void Insert(T value)
        {
            root = Insert(root, value);
        }

        private Node<T> Insert(Node<T> node, T value)
        {
            if (node == null) return new Node<T>(value);

            if (value.CompareTo(node.Value) < 0)
                node.Left = Insert(node.Left, value);
            else
                node.Right = Insert(node.Right, value);

            return node;
        }

        public T Search(int id)
        {
            return Search(root, id);
        }

        private T Search(Node<T> node, int id)
        {
            if (node == null) return default;

            if (node.Value as ServiceRequest != null && (node.Value as ServiceRequest).RequestId == id)
                return node.Value;

            if (id.CompareTo((node.Value as ServiceRequest)?.RequestId) < 0)
                return Search(node.Left, id);

            return Search(node.Right, id);
        }

        public List<T> InOrderTraversal()
        {
            var items = new List<T>();
            InOrderTraversal(root, items);
            return items;
        }

        private void InOrderTraversal(Node<T> node, List<T> items)
        {
            if (node == null) return;

            InOrderTraversal(node.Left, items);
            items.Add(node.Value);
            InOrderTraversal(node.Right, items);
        }
    }

    public class Node<T>
    {
        public T Value { get; set; }
        public Node<T> Left { get; set; }
        public Node<T> Right { get; set; }

        public Node(T value)
        {
            Value = value;
        }
    }
}