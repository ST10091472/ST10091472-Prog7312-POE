﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CitizenCare
{

    public partial class LocalEventsWindow : Window
    {
        // Data structures for managing events
        private SortedDictionary<DateTime, Queue<Event>> eventsByDate = new SortedDictionary<DateTime, Queue<Event>>();
        private Dictionary<string, HashSet<Event>> eventsByCategory = new Dictionary<string, HashSet<Event>>();
        private Stack<Event> searchHistory = new Stack<Event>();

        public LocalEventsWindow()
        {
            InitializeComponent();
            LoadSampleEvents();
            DisplayEvents();
        }

        // Sample events for demonstration
        private void LoadSampleEvents()
        {
            AddEvent("Concert", new DateTime(2024, 10, 12), "Music");
            AddEvent("Tech Meetup", new DateTime(2024, 10, 13), "Technology");
            AddEvent("Art Festival", new DateTime(2024, 10, 14), "Arts");
            AddEvent("Music Concert", new DateTime(2024, 10, 15), "Music");
            AddEvent("Tech Conference", new DateTime(2024, 10, 20), "Technology");
            AddEvent("Art Exhibition", new DateTime(2024, 11, 5), "Arts");
            AddEvent("Startup Pitch Event", new DateTime(2024, 11, 10), "Business");
            AddEvent("Charity Run", new DateTime(2024, 10, 18), "Sports");
            AddEvent("Jazz Night", new DateTime(2024, 10, 17), "Music");
            AddEvent("Community Cleanup", new DateTime(2024, 11, 2), "Volunteer");
            AddEvent("Open Mic Night", new DateTime(2024, 11, 12), "Entertainment");
            AddEvent("Career Fair", new DateTime(2024, 10, 28), "Business");
            AddEvent("Book Club Meeting", new DateTime(2024, 11, 8), "Literature");
            AddEvent("Football Tournament", new DateTime(2024, 10, 22), "Sports");
            AddEvent("Painting Workshop", new DateTime(2024, 11, 6), "Arts");
            AddEvent("Yoga Session", new DateTime(2024, 10, 30), "Health & Wellness");
            AddEvent("Cooking Class", new DateTime(2024, 11, 14), "Lifestyle");
        }

        // Add event to the data structures
        private void AddEvent(string name, DateTime date, string category)
        {
            Event newEvent = new Event(name, date, category);

            // Add to events by date (using priority queue - queue in SortedDictionary)
            if (!eventsByDate.ContainsKey(date))
                eventsByDate[date] = new Queue<Event>();
            eventsByDate[date].Enqueue(newEvent);

            // Add to events by category (using HashSet for uniqueness)
            if (!eventsByCategory.ContainsKey(category))
                eventsByCategory[category] = new HashSet<Event>();
            eventsByCategory[category].Add(newEvent);
        }

        // Display all events in the ListView
        private void DisplayEvents()
        {
            EventsListView.Items.Clear();

            foreach (var eventQueue in eventsByDate.Values)
            {
                foreach (var ev in eventQueue)
                {
                    EventsListView.Items.Add(ev);
                }
            }
        }

        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (string.IsNullOrEmpty(SearchTextBox.Text))
            {
                PlaceholderTextBlock.Visibility = Visibility.Visible;
            }
            else
            {
                PlaceholderTextBlock.Visibility = Visibility.Hidden;
            }
        }
        // Search Button click handler
        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            EventsListView.Items.Clear();
            string searchCategory = SearchTextBox.Text;
            DateTime? selectedDate = DateFilter.SelectedDate;

            // Filter by category and/or date
            if (!string.IsNullOrEmpty(searchCategory) && eventsByCategory.ContainsKey(searchCategory))
            {
                foreach (var ev in eventsByCategory[searchCategory])
                {
                    if (selectedDate == null || ev.EventDate == selectedDate.Value)
                    {
                        EventsListView.Items.Add(ev);
                        searchHistory.Push(ev); // Add to search history for recommendation
                    }
                }
            }
            else if (selectedDate != null)
            {
                if (eventsByDate.ContainsKey(selectedDate.Value))
                {
                    foreach (var ev in eventsByDate[selectedDate.Value])
                    {
                        EventsListView.Items.Add(ev);
                        searchHistory.Push(ev); // Add to search history
                    }
                }
            }

            DisplayRecommendations();
        }

        // Display recommended events based on search history
        private void DisplayRecommendations()
        {
            RecommendationsListView.Items.Clear();

            if (searchHistory.Count > 0)
            {
                var lastSearchedEvent = searchHistory.Peek();
                if (eventsByCategory.ContainsKey(lastSearchedEvent.Category))
                {
                    foreach (var ev in eventsByCategory[lastSearchedEvent.Category])
                    {
                        if (ev.EventDate >= DateTime.Now && ev != lastSearchedEvent) // Avoid showing the last searched event
                        {
                            RecommendationsListView.Items.Add(ev);
                        }
                    }
                }
            }
        }
    }

    // Event class definition
    public class Event
    {
        public string EventName { get; set; }
        public DateTime EventDate { get; set; }
        public string Category { get; set; }

        public Event(string name, DateTime date, string category)
        {
            EventName = name;
            EventDate = date;
            Category = category;
        }

        // Override ToString for ListView display
        public override string ToString()
        {
            return $"{EventName} - {EventDate.ToShortDateString()} - {Category}";
        }
    }
}
